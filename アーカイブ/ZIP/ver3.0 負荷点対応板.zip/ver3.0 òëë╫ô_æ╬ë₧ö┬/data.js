const s = [
  String.fromCodePoint(993803),
  String.fromCodePoint(993807),
  String.fromCodePoint(993811),
  String.fromCodePoint(993815),
  String.fromCodePoint(993819),
];
const z = [
  String.fromCodePoint(993804),
  String.fromCodePoint(993808),
  String.fromCodePoint(993812),
  String.fromCodePoint(993816),
  String.fromCodePoint(993820),
];
const s2 = [
  String.fromCodePoint(993805),
  String.fromCodePoint(993809),
  String.fromCodePoint(993813),
  String.fromCodePoint(993817),
  String.fromCodePoint(993821),
];
const z2 = [
  String.fromCodePoint(993806),
  String.fromCodePoint(993810),
  String.fromCodePoint(993814),
  String.fromCodePoint(993818),
  String.fromCodePoint(993822),
];
const sh = [
  String.fromCodePoint(993823),
  String.fromCodePoint(993827),
  String.fromCodePoint(993831),
  String.fromCodePoint(993835),
  String.fromCodePoint(993839),
];
const zh = [
  String.fromCodePoint(993824),
  String.fromCodePoint(993828),
  String.fromCodePoint(993832),
  String.fromCodePoint(993836),
  String.fromCodePoint(993840),
];
const sh2 = [
  String.fromCodePoint(993825),
  String.fromCodePoint(993829),
  String.fromCodePoint(993833),
  String.fromCodePoint(993837),
  String.fromCodePoint(993841),
];
const zh2 = [
  String.fromCodePoint(993826),
  String.fromCodePoint(993830),
  String.fromCodePoint(993834),
  String.fromCodePoint(993838),
  String.fromCodePoint(993842),
];
const t = [
  String.fromCodePoint(993843),
  String.fromCodePoint(993847),
  String.fromCodePoint(993851),
  String.fromCodePoint(993855),
  String.fromCodePoint(993859),
];
const d = [
  String.fromCodePoint(993844),
  String.fromCodePoint(993848),
  String.fromCodePoint(993852),
  String.fromCodePoint(993856),
  String.fromCodePoint(993860),
];
const t2 = [
  String.fromCodePoint(993845),
  String.fromCodePoint(993849),
  String.fromCodePoint(993853),
  String.fromCodePoint(993857),
  String.fromCodePoint(993861),
];
const d2 = [
  String.fromCodePoint(993846),
  String.fromCodePoint(993850),
  String.fromCodePoint(993854),
  String.fromCodePoint(993858),
  String.fromCodePoint(993862),
];
const f = [
  String.fromCodePoint(993863),
  String.fromCodePoint(993869),
  String.fromCodePoint(993875),
  String.fromCodePoint(993881),
  String.fromCodePoint(993887),
];
const v = [
  String.fromCodePoint(993864),
  String.fromCodePoint(993870),
  String.fromCodePoint(993876),
  String.fromCodePoint(993882),
  String.fromCodePoint(993888),
];
const b = [
  String.fromCodePoint(993865),
  String.fromCodePoint(993871),
  String.fromCodePoint(993877),
  String.fromCodePoint(993883),
  String.fromCodePoint(993889),
];
const f2 = [
  String.fromCodePoint(993866),
  String.fromCodePoint(993872),
  String.fromCodePoint(993878),
  String.fromCodePoint(993884),
  String.fromCodePoint(993890),
];
const v2 = [
  String.fromCodePoint(993867),
  String.fromCodePoint(993873),
  String.fromCodePoint(993879),
  String.fromCodePoint(993885),
  String.fromCodePoint(993891),
];
const b2 = [
  String.fromCodePoint(993868),
  String.fromCodePoint(993874),
  String.fromCodePoint(993880),
  String.fromCodePoint(993886),
  String.fromCodePoint(993892),
];
const h = [
  String.fromCodePoint(993893),
  String.fromCodePoint(993899),
  String.fromCodePoint(993905),
  String.fromCodePoint(993911),
  String.fromCodePoint(993917),
];
const k = [
  String.fromCodePoint(993894),
  String.fromCodePoint(993900),
  String.fromCodePoint(993906),
  String.fromCodePoint(993912),
  String.fromCodePoint(993918),
];
const g = [
  String.fromCodePoint(993895),
  String.fromCodePoint(993901),
  String.fromCodePoint(993907),
  String.fromCodePoint(993913),
  String.fromCodePoint(993919),
];
const h2 = [
  String.fromCodePoint(993896),
  String.fromCodePoint(993902),
  String.fromCodePoint(993908),
  String.fromCodePoint(993914),
  String.fromCodePoint(993920),
];
const k2 = [
  String.fromCodePoint(993897),
  String.fromCodePoint(993903),
  String.fromCodePoint(993909),
  String.fromCodePoint(993915),
  String.fromCodePoint(993921),
];
const g2 = [
  String.fromCodePoint(993898),
  String.fromCodePoint(993904),
  String.fromCodePoint(993910),
  String.fromCodePoint(993916),
  String.fromCodePoint(993922),
];
const l = [
  String.fromCodePoint(993923),
  String.fromCodePoint(993927),
  String.fromCodePoint(993931),
  String.fromCodePoint(993935),
  String.fromCodePoint(993939),
];
const r = [
  String.fromCodePoint(993924),
  String.fromCodePoint(993928),
  String.fromCodePoint(993932),
  String.fromCodePoint(993936),
  String.fromCodePoint(993940),
];
const l2 = [
  String.fromCodePoint(993925),
  String.fromCodePoint(993929),
  String.fromCodePoint(993933),
  String.fromCodePoint(993937),
  String.fromCodePoint(993941),
];
const r2 = [
  String.fromCodePoint(993926),
  String.fromCodePoint(993930),
  String.fromCodePoint(993934),
  String.fromCodePoint(993938),
  String.fromCodePoint(993942),
];
const n = [
  String.fromCodePoint(993943),
  String.fromCodePoint(993945),
  String.fromCodePoint(993947),
  String.fromCodePoint(993949),
  String.fromCodePoint(993951),
];
const n2 = [
  String.fromCodePoint(993944),
  String.fromCodePoint(993946),
  String.fromCodePoint(993948),
  String.fromCodePoint(993950),
  String.fromCodePoint(993952),
];
const m = [
  String.fromCodePoint(993953),
  String.fromCodePoint(993955),
  String.fromCodePoint(993957),
  String.fromCodePoint(993959),
  String.fromCodePoint(993961),
];
const m2 = [
  String.fromCodePoint(993954),
  String.fromCodePoint(993956),
  String.fromCodePoint(993958),
  String.fromCodePoint(993960),
  String.fromCodePoint(993962),
];
const j = [
  String.fromCodePoint(993963),
  String.fromCodePoint(993965),
  String.fromCodePoint(993967),
  String.fromCodePoint(993969),
  String.fromCodePoint(993971),
];
const j2 = [
  String.fromCodePoint(993964),
  String.fromCodePoint(993966),
  String.fromCodePoint(993968),
  String.fromCodePoint(993970),
  String.fromCodePoint(993972),
];

const 子音一覧 = [
  s,
  z,
  s2,
  z2,
  sh,
  zh,
  sh2,
  zh2,
  t,
  d,
  t2,
  d2,
  f,
  v,
  b,
  f2,
  v2,
  b2,
  h,
  k,
  g,
  h2,
  k2,
  g2,
  l,
  r,
  l2,
  r2,
  n,
  n2,
  m,
  m2,
  j,
  j2,
];

const 子音文字 = [].concat(...子音一覧);

const 母音 = [
  String.fromCodePoint(993975),
  String.fromCodePoint(993976),
  String.fromCodePoint(993977),
  String.fromCodePoint(993978),
  String.fromCodePoint(993979),
];

let combinations = [];

for (let i = 0; i < 子音一覧.length; i++) {
  for (let j = 0; j < 母音.length; j++) {
    combinations.push({
      consonant: 子音一覧[i],
      vowel: 母音[j],
      char: 子音一覧[i][j],
    });
  }
}

const 負荷点 = [String.fromCodePoint(993993), String.fromCodePoint(993994)];

function 第一負荷点ペア作成(S, Z, combinations) {
  // sとzは一例
  for (let i = 0; i < S.length; i++) {
    combinations.push(
      {
        consonant: S[i],
        vowel: String.fromCodePoint(993993),
        char: Z[i],
      },
      {
        consonant: Z[i],
        vowel: String.fromCodePoint(993993),
        char: S[i],
      }
    );
  }
}

function 第二負荷点ペア生成(F, V, B, combinations) {
  for (let i = 0; i < F.length; i++) {
    combinations.push(
      {
        consonant: F[i],
        vowel: String.fromCodePoint(993993),
        char: V[i],
      },
      {
        consonant: V[i],
        vowel: String.fromCodePoint(993993),
        char: F[i],
      },
      {
        consonant: B[i],
        vowel: String.fromCodePoint(993993),
        char: V[i],
      },
      {
        consonant: F[i],
        vowel: String.fromCodePoint(993994),
        char: B[i],
      },
      {
        consonant: B[i],
        vowel: String.fromCodePoint(993994),
        char: F[i],
      },
      {
        consonant: V[i],
        vowel: String.fromCodePoint(993994),
        char: B[i],
      }
    );
  }
}

第一負荷点ペア作成(s, z, combinations);
第一負荷点ペア作成(s2, z2, combinations);
第一負荷点ペア作成(sh, zh, combinations);
第一負荷点ペア作成(sh2, zh2, combinations);
第一負荷点ペア作成(t, d, combinations);
第一負荷点ペア作成(t2, d2, combinations);
第二負荷点ペア生成(f, v, b, combinations);
第二負荷点ペア生成(f2, v2, b2, combinations);
第一負荷点ペア作成(l, r, combinations);
第一負荷点ペア作成(l2, r2, combinations);
